import { useState } from "react";
import "./App.css";
import { Formulario } from "./components/Formulario";
import { ListaClientes } from "./components/ListaClientes";

function App() {
  const [viajeros, setViajeros] = useState([]);

  return (
    <div className="w-full max-w-screen-lg mx-auto py-10 grid grid-cols-2 gap-10">
      <Formulario viajeros={viajeros} setViajeros={setViajeros} />
      <ListaClientes viajeros={viajeros}/>
    </div>
  );
}

export default App;
