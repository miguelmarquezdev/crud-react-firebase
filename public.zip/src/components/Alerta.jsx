export const Alerta = ({children}) => {
  return (
    <div className="text-white bg-red-600 font-bold text-center">
      {children}
    </div>
  );
};
