import React from "react";

export const Viajero = ({ viajero }) => {
  const { nombre, whatsapp, fecha, hotel, tour, apuntes } = viajero;
  return (
    <tr>
      <td class="border-b border-slate-100 dark:border-slate-700 p-4 pl-8 text-slate-500 dark:text-slate-400">
        {nombre}
      </td>
      <td class="border-b border-slate-100 dark:border-slate-700 p-4 text-slate-500 dark:text-slate-400">
        {whatsapp}
      </td>
      <td class="border-b border-slate-100 dark:border-slate-700 p-4 pr-8 text-slate-500 dark:text-slate-400">
        {fecha}
      </td>
      <td class="border-b border-slate-100 dark:border-slate-700 p-4 pr-8 text-slate-500 dark:text-slate-400">
        {hotel}
      </td>
      <td class="border-b border-slate-100 dark:border-slate-700 p-4 pr-8 text-slate-500 dark:text-slate-400">
        {tour}
      </td>
      <td class="border-b border-slate-100 dark:border-slate-700 p-4 pr-8 text-slate-500 dark:text-slate-400">
        {apuntes}
      </td>
    </tr>
  );
};
