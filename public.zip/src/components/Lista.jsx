export const Lista = (props) => {
  return (
    <li>Hola soy <strong>{props.name} </strong> y mis redes sociales son: <strong>{props.iconos}{props.rech}</strong></li>
  )
}
