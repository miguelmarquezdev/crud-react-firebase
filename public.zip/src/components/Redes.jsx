import React from "react";

const Redes = (props) => {
  return (
    <li className={`flex items-center gap-1 list-disc ${props.className}`}>
      <span>{props.iconored}</span> {props.rednombre}
    </li>
  );
};

export default Redes;
