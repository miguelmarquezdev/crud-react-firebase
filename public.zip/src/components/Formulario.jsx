import React, { useState } from "react";
import { Alerta } from "./Alerta";

export const Formulario = ({ viajeros, setViajeros }) => {
  const [nombre, setNombre] = useState("");
  const [whatsapp, setWhatsapp] = useState("");
  const [fecha, setFecha] = useState("");
  const [hotel, setHotel] = useState("");
  const [tour, setTour] = useState("");
  const [apuntes, setApuntes] = useState("");

  const [error, setError] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();

    //validando formulario
    if ([nombre, whatsapp, fecha, hotel, tour, apuntes].includes("")) {
      setError(true);
      return;
    }
    setError(false);
    
    
    //Creamos un objeto con todos los datos
    const objetoViajero = {
      nombre,
      whatsapp,
      fecha,
      hotel,
      tour,
      apuntes,
    };

    setViajeros([...viajeros, objetoViajero]);

    //reiniciar el formulario
    setNombre("");
    setWhatsapp("");
    setApuntes("");
    setFecha("");
    setTour("");
    setHotel("");
  };

  return (
    <div>
      <h2 className="text-xl text-bold text-black mb-5">
        Ingresa datos del Cliente
      </h2>
      <form
        onSubmit={handleSubmit}
        className="flex flex-col gap-5 border p-10 rounded-lg border-neutral-200 shadow-lg"
      >
        {error && <Alerta><p>Todos los campos son necesarios</p></Alerta>}
        <label htmlFor="nombre">
          <span className="inline-block  pb-2">Nombre del Viajero</span>
          <input
            type="text"
            id="nombre"
            placeholder="Nombre"
            className="border rounded  w-full p-2"
            value={nombre}
            onChange={(e) => setNombre(e.target.value)}
          />
        </label>
        <label htmlFor="whatsapp">
          <span className="inline-block  pb-2">Numero de Whatsapp</span>
          <input
            type="text"
            id="whatsapp"
            placeholder="Whatsapp"
            className="border rounded w-full p-2"
            value={whatsapp}
            onChange={(e) => setWhatsapp(e.target.value)}
          />
        </label>
        <label htmlFor="fecha">
          <span className="inline-block  pb-2">Fecha de Viaje</span>
          <input
            type="date"
            id="date"
            placeholder="fecha de viaje"
            className="border rounded  w-full p-2"
            value={fecha}
            onChange={(e) => setFecha(e.target.value)}
          />
        </label>
        <label htmlFor="hotel">
          <span className="inline-block  pb-2">Nombre del Hotel</span>
          <input
            type="text"
            id="hotel"
            placeholder="Hotel"
            className="border rounded  w-full p-2"
            value={hotel}
            onChange={(e) => setHotel(e.target.value)}
          />
        </label>
        <label htmlFor="tour">
          <span className="inline-block  pb-2">Tour</span>
          <input
            type="text"
            id="tour"
            placeholder="Nombre del Tour"
            className="border rounded  w-full p-2"
            value={tour}
            onChange={(e) => setTour(e.target.value)}
          />
        </label>
        <label htmlFor="apuntes">
          <span className="inline-block  pb-2">Notas del Cliente</span>
          <textarea
            name=""
            id="apuntes"
            cols="30"
            rows="10"
            placeholder="Apuntes"
            className="border rounded  w-full p-2"
            value={apuntes}
            onChange={(e) => setApuntes(e.target.value)}
          ></textarea>
        </label>
        <button className="bg-blue-600 py-2 w-full text-white rounded hover:bg-blue-700 transition-all duration-300">
          enviar
        </button>
      </form>
    </div>
  );
};
