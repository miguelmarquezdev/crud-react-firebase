import React from "react";
import { Viajero } from "./Viajero";

export const ListaClientes = ({ viajeros }) => {
  return (
    <table className="border-collapse table-auto w-full text-sm">
      <thead>
        <tr>
          <th className="border-b dark:border-slate-600 font-medium p-4 pl-8 pt-0 pb-3 text-slate-400 dark:text-slate-200 text-left">
            Nombre
          </th>
          <th className="border-b dark:border-slate-600 font-medium p-4 pt-0 pb-3 text-slate-400 dark:text-slate-200 text-left">
            Whatsapp
          </th>
          <th className="border-b dark:border-slate-600 font-medium p-4 pr-8 pt-0 pb-3 text-slate-400 dark:text-slate-200 text-left">
            Fecha de Viaje
          </th>
          <th className="border-b dark:border-slate-600 font-medium p-4 pr-8 pt-0 pb-3 text-slate-400 dark:text-slate-200 text-left">
            Hotel
          </th>
          <th className="border-b dark:border-slate-600 font-medium p-4 pr-8 pt-0 pb-3 text-slate-400 dark:text-slate-200 text-left">
            Tour
          </th>
          <th className="border-b dark:border-slate-600 font-medium p-4 pr-8 pt-0 pb-3 text-slate-400 dark:text-slate-200 text-left">
            Apuntes
          </th>
        </tr>
      </thead>
      <tbody className="bg-white dark:bg-slate-800">
        {viajeros.map((viajero) => (
          <Viajero key={viajero.nombre} viajero={viajero} />
        ))}
      </tbody>
    </table>
  );
};
